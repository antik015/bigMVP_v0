# bigMVP
R package for implementing fast two-stage approximations of multivariate probit model. Main function is bigMVP(). To install the package, first install the "devtools" package using install.packages("devtools"). Then use install_github("antik015/bigMVP").
